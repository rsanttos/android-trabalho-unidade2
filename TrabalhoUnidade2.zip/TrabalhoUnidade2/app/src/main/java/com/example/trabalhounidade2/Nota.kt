package com.example.trabalhounidade2

data class Nota (var titulo: String, var texto: String)