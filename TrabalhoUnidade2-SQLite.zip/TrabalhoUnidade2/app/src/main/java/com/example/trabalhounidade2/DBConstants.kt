package com.example.trabalhounidade2

const val DATABASE_NAME = "dbnotas"
const val DATABASE_VERSION = 1
const val TABLE_NAME = "nota"
const val COLUMN_ID = "_id"
const val COLUMN_TITULO = "titulo"
const val COLUMN_TEXTO = "texto"